/**
 * Kyla Kane-Maystead
 * Assignment 1
 * This class is designed to create a doubly linked list
 * structure.
 */

package cs2321;
import java.util.NoSuchElementException;
import java.util.Iterator;

import net.datastructures.Position;
import net.datastructures.PositionalList;

public class DoublyLinkedList<E> implements PositionalList<E> {
	
	// Instance Variables
	private Node<E> head;    //header sentinel
	private Node<E> trail;   //trailer sentinel
	private int size = 0;
	
	private static class Node<E> implements Position<E> {
		
		private E element;
		private Node<E> prev;
		private Node<E> next;
		
		public Node(E e, Node<E> p, Node<E> n) {
			element = e;
			prev = p;
			next = n;
		}
		
		/**
		 * Returns element from the list
		 * @throws IllegalStateException when the next node is
		 * equal to no
		 */
		public E getElement() throws IllegalStateException {
			if(next == null) 
				throw new IllegalStateException("Position not valid");
			return element;
		}
		
		/**
		 * Returns previous node
		 * @return previous node
		 */
		public Node<E> getPrev() {
			return prev;
		}
		
		/**
		 * Returns next node
		 * @return next node
		 */
		public Node<E> getNext() {
			return next;
		}
		
		/**
		 * Sets element variable to parameter
		 * @param e element
		 */
		public void setElement(E e) {
			element = e;
		}
		
		/**
		 * Sets previous node to parameter
		 * @param p node
		 */
		public void setPrev(Node<E> p) {
			prev = p;
		}
		
		/**
		 * Sets next node to parameter
		 * @param n node
		 */
		public void setNext(Node<E> n) {
			next = n;
		}
	}
	
	public class PosIterator implements Iterator<Position<E>> {
		
		private Position<E> cursor = first();
		private Position<E> recent = null;
		
		@Override
		public boolean hasNext() {
			return cursor != null;
		}

		@Override
		@TimeComplexity("O(1)")
		public Position<E> next() throws NoSuchElementException	{
			/* TCJ
			 * This method returns the next element depending on where 
			 * the cursor is, so it only goes through 1 element.
			 */
			if(cursor == null)
				throw new NoSuchElementException("Nothing Left");
			recent = cursor;
			cursor = after(cursor);
			return recent;
		}
		
		/**
		 * Removes a certain element from the list.
		 * @throws IllegalStateException if the doubly linked list is empty
		 */
		@TimeComplexity("O(1)")
		public void remove() throws IllegalStateException {
			/* TCJ
			 * This method returns and calls the remove method for 
			 * an element so it only goes through 1 element.
			 */
			if(recent == null)
				throw new IllegalStateException("Nothing to remove");
			DoublyLinkedList.this.remove(recent);		//remove from outer list
			recent = null;								//don't allow remove again until next is called
		}
		
	}
	
	private class PosIterable implements Iterable<Position<E>> {

		@Override
		public Iterator<Position<E>> iterator() {
			return new PosIterator();
		}
		
	}
	
	private class IteratorClass implements Iterator<E> {

		Iterator<Position<E>> posIterator = new PosIterator();
		
		@Override
		public boolean hasNext() {
			return posIterator.hasNext();
		}

		@Override
		public E next() {
			return posIterator.next().getElement(); 
		}
		
		/**
		 * Calls the remove method where the position of the
		 * iterator is.
		 */
		public void remove() {
			posIterator.remove();
		}
		
	}
		
	//Constructs new empty list
	public DoublyLinkedList() {
		head = new Node<>(null, null, null);
		trail = new Node<>(null, head, null);
		head.setNext(trail);
	}
	
	//Validates the position and returns it as a node
	@TimeComplexity("O(1)")
	private Node<E> validate(Position<E> p) throws IllegalArgumentException {
		/* TCJ
		 * This method checks the position of a node to make sure it is in the list
		 * so it will go through 1 element. 
		 */
		if(!(p instanceof Node)) throw new IllegalArgumentException("Invalid position");
		Node<E> node = (Node<E>) p; 	//cast
		if(node.getNext() == null) 		//convention for defunct node
			throw new IllegalArgumentException("Position is no longer in the list");
		return node;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}
	
	/**
	 * This method returns the node if it isn't the header or
	 * trailer sentinel.
	 * @param node 
	 * @return node
	 */
	private Position<E> position(Node<E> node) {
		if(node == head || node == trail) 
			return null;
		return node;
	}

	@Override
	public Position<E> first() {
		return position(head.getNext());
	}

	@Override
	public Position<E> last() {
		return position(trail.getPrev());
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		/* TCJ
		 * This method returns the position of the previous node from a certain
		 * node so it only goes through 1 element. 
		 */
		Node<E> node = validate(p);
		return position(node.getPrev());
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		/* TCJ
		 * This method returns the position of the element after a certain position
		 * so it only runs through 1 element.
		 */
		Node<E> node = validate(p);
		return position(node.getNext());
	}
	
	/**
	 * Returns position of element that is being added between two 
	 * nodes
	 * @param e element that is being added to the list
	 * @param pred the previous node
	 * @param succ the next node
	 * @return position of element that is being added between two nodes
	 */
	@TimeComplexity("O(1)")
	private Position<E> addBetween(E e, Node<E> pred, Node<E> succ) {
		/* TCJ
		 * This method returns position of element that is being added
		 * between two certain nodes so it only goes through 1 element
		 */
		Node<E> newer = new Node<>(e, pred, succ);  //create and link a new node
		pred.setNext(newer);
		succ.setPrev(newer);
		size++;
		return newer;
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> addFirst(E e) {
		/* TCJ
		 * This method returns the position of the element
		 * that is getting added to the front of the list
		 * so it goes through 1 element.
		 */
		return addBetween(e, head, head.getNext());
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> addLast(E e) {
		/* TCJ
		 * This method returns the position of the element
		 * that is getting added so it goes through 1 element. 
		 */
		return addBetween(e, trail.getPrev(), trail);
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> addBefore(Position<E> p, E e)
			throws IllegalArgumentException {
		/* TCJ
		 * This method returns the position of the element
		 * that is being added so it goes through 1 element. 
		 */
		Node<E> node = validate(p);
		return addBetween(e, node.getPrev(), node);
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> addAfter(Position<E> p, E e)
			throws IllegalArgumentException {
		/* TCJ
		 * This method returns the position of the element
		 * that is added to the list so it only goes through 
		 * 1 element.
		 */
		Node<E> node = validate(p);
		return addBetween(e, node, node.getNext());
	}

	@Override
	@TimeComplexity("O(1)")
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		/* TCJ
		 * This method sets a certain position of the list to be
		 * an element so it only goes through 1 element. 
		 */
		Node<E> node = validate(p);
		E answer = node.getElement();
		node.setElement(e);
		return answer;
	}

	@Override
	@TimeComplexity("O(1)")
	public E remove(Position<E> p) throws IllegalArgumentException {
		/* TCJ
		 * This method returns the element from a certain position and
		 * invalidates it so at worst case it would only go through 
		 * 1 element. 
		 */
		Node<E> node = validate(p);
		Node<E> pred = node.getPrev();
		Node<E> succ = node.getNext();
		pred.setNext(succ);
		succ.setPrev(pred);
		size--;
		E answer = node.getElement();
		node.setElement(null);    // help with garbage collection
		node.setNext(null); 	  // convention for defunct node
		node.setPrev(null);
		return answer;
	}

	@Override
	public Iterator<E> iterator() {
		return new IteratorClass();
	}

	@Override
	public Iterable<Position<E>> positions() {
		return new PosIterable();			//Create new instance of inner class
	}
	
	/**
	 * Returns and removes the first element of the doubly
	 * linked list. 
	 * @return first element that is getting removed
	 * @throws IllegalArgumentException
	 */
	public E removeFirst() throws IllegalArgumentException { 
		if(isEmpty())
			throw new IllegalArgumentException("Nothing to remove");
		return remove(first());
	}
	
	/**
	 * Returns and removes the first element of the doubly
	 * linked list. 
	 * @return last element that is getting removed
	 * @throws IllegalArgumentException
	 */
	public E removeLast() throws IllegalArgumentException {
		if(isEmpty())
			throw new IllegalArgumentException("Nothing to remove");
		return remove(last());
	}

}
