package cs2321.sorting;

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place heap sort
	 * @param array - Array to sort
	 */
	
	public void sort(K[] array) {
		// TODO Auto-generated method stub
	}

}
