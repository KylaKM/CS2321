package cs2321.sorting;

public class QuickSort<E extends Comparable<E>> implements Sorter<E> {

	public void sort(E[] array) {
		// TODO Auto-generated method stub

	}
}
