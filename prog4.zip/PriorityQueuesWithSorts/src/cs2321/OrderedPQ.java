package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an ordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Kyla Kane-Maystead
 */

public class OrderedPQ<K,V> implements PriorityQueue<K,V> {
	
	// Instance Variables
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<Entry<K,V>>();
	private Comparator<K> c;
	
	protected static class PQEntry<K,V> implements Entry<K,V> {
		
		private K k;
		private V v;
		
		public PQEntry(K key, V value) {
			k = key;
			v = value;
		}
		
		public K getKey() {
			return k;
		}
		
		public V getValue() {
			return v;
		}
		
		protected void setKey(K key) {
			k = key;
		}
		
		protected void setValue(V value) {
			v = value;
		}
	}
	
	// Constructors
	public OrderedPQ() {
		this(new DefaultComparator<K>());
	}
	
	public OrderedPQ(Comparator<K> c) {
		this.c = c;
	}
	
	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return list.size();
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return list.size() == 0;
	}
	
	/**
	 * Checks whether the key is valid
	 * @param key
	 * @return true if key is valid, false otherwise
	 * @throws IllegalArgumentException if key is invalid
	 */
	@TimeComplexity("O(1)")
	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (c.compare(key, key) == 0);   // Checks key with itself
		}
		catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible key");
		}
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		/* TCJ
		 * For an ordered pq, insert will put the entries in order from min to
		 * max. So, in the worst case scenario the method will go through n elements
		 * to add the entry to the beginning of the list.
		 */
		checkKey(key);  // Calls checkKey to make sure it's valid
		Entry<K,V> newest = new PQEntry<>(key, value);
		Position<Entry<K,V>> walk = list.last();  
		while (walk != null && c.compare(newest.getKey(), walk.getElement().getKey()) < 0)   // while list has elements, and last key is greater than previous 
			walk = list.before(walk); // Move to next element
		if (walk == null)		// If end of list
			list.addFirst(newest);
		else
			list.addAfter(walk, newest);
		return newest;
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> min() {
		if(isEmpty())		// If pq is empty, return null
			return null;
		return list.first().getElement();		// Return first element
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> removeMin() {
		if(isEmpty())   	// If pq is empty, return null
			return null;
		return list.removeFirst();	// Remove and return first element
	}
}
