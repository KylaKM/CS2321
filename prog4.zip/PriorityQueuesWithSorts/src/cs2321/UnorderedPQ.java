package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an Unordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Kyla Kane-Maystead
 */

public class UnorderedPQ<K,V> implements PriorityQueue<K,V> {
	
	// Instance Variables
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<Entry<K,V>>();
	private Comparator<K> c;
	
	protected static class PQEntry<K,V> implements Entry<K,V> {
		private K k;
		private V v;
		
		public PQEntry(K key, V value) {
			k = key;
			v = value;
		}
		
		public K getKey() {
			return k;
		}
		
		public V getValue() {
			return v;
		}
		
		protected void setKey(K key) {
			k = key;
		}
		
		protected void setValue(V value) {
			v = value;
		}
	}
	
	// Constructors
	public UnorderedPQ() {
		this(new DefaultComparator<K>());
	}
	
	public UnorderedPQ(Comparator<K> c) {
		this.c = c;
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return list.size();
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return list.size() == 0;
	}
	
	/**
	 * Checks if key is valid
	 * @param key
	 * @return true if key is valid, otherwise false
	 * @throws IllegalArgumentException if key is invalid
	 */
	@TimeComplexity("O(1)")
	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (c.compare(key, key) == 0);   // Checks key with itself
		}
		catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible key");
		}
	}
	
	/**
	 * Finds and returns the minimum key in the list.
	 * @return minimum entry of the list
	 */
	@TimeComplexity("O(n)")
	private Position<Entry<K, V>> findMin() {
		/* TCJ
		 * Since this is an unordered pq, the minimum key could be 
		 * anywhere in the list so in it's worst case it will go 
		 * through n elements to find the minimum key.
		 */
		Position<Entry<K,V>> small = list.first();
		for(Position<Entry<K,V>> walk: list.positions()) {
			if(c.compare(walk.getElement().getKey(), small.getElement().getKey()) < 0)  // If next element is less than first
				small = walk;		// change smallest element to current
		}
		return small;		// return min entry
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key); 	// Check if key is valid
		Entry<K,V> newest = new PQEntry<>(key, value);
		list.addLast(newest);	// Adds entry to end of the list
		return newest;		// Return entry
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> min() {
		/* TCJ
		 * This method utilizes a method call to find the minimum key
		 * so its worst case time complexity will be O(n). Also, since
		 * its an unordered pq, the minimum entry could be anywhere so
		 * in worst case it will go through n elements. 
		 */
		if(isEmpty()) 		// If pq is empty, return null
			return null;
		return findMin().getElement();		// Return min element
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> removeMin() {
		/* TCJ
		 * This method utilizes method calls to find and remove the minimum
		 * key so its time complexity will be O(n). Also, the minimum entry
		 * could be anywhere in the list so finding the min could take up
		 * to n elements to find.
		 */
		if(isEmpty())		// If empty, return null
			return null;
		return list.remove(findMin());		// Remove and Return min element
	}
}
