/**
 * Kyla Kane-Maystead
 * Assignment 4
 * This class is designed to sort an array with InPlaceHeap Sort.
 */
package cs2321.sorting;

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {

	protected int heapsize;
	/**
	 * sort - Perform an in-place heap sort
	 * @param array - Array to sort
	 */
	@TimeComplexity("O(nlogn)")
	public void sort(K[] array) {
		heapsize = array.length;
		buildMaxHeap(array);	// Make heap to follow max heap order, where max is root node
		for(int i = array.length - 1; i >= 1; i--) {
			swap(array, 0, i);	// Swap max root node with leaf
			heapsize--;
			maxHeapify(0, array);	// Maxheapify the new root node
		}
	}
	
	@TimeComplexity("O(logn)")
	public void buildMaxHeap(K[] array) {
		heapsize = array.length;
		for(int i = array.length/2 - 1; i >= 0; i--) 
			maxHeapify(i, array);		// Call maxHeapify 
	}
	
	@TimeComplexity("O(n)")
	public void maxHeapify(int i, K[] array) {
		int m = i;
		int left = left(i);
		int right = right(i);
		if(left < heapsize && array[left].compareTo(array[m]) > 0)		// If left child is greater than parent, then max is left child
			m = left;									
		if(right < heapsize && array[right].compareTo(array[m]) > 0)	// If right child is greater than parent, then max is right child
			m = right;
		if(m != i) {
			swap(array, i, m);		// Swap elements at the two indices
			maxHeapify(m, array);	// Call maxHeapify to see if new element at node is greater than children
		}
	}
	
	@TimeComplexity("O(1)")
	public int left(int i) {
		return (2 * i) + 1;		// index of left child
	}
	
	@TimeComplexity("O(1)")
	public int right(int i) {
		return (2 * i) + 2;		// index of right child
	}
	
	@TimeComplexity("O(1)")
	public void swap(K[] array, int i, int j) {
		K temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
}
