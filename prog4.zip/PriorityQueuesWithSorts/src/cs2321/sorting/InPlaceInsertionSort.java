/**
 * Kyla Kane-Maystead
 * Assignment 4
 * This class is designed to sort an array with InPlaceInsertion Sort.
 */
package cs2321.sorting;

public class InPlaceInsertionSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place insertion sort
	 * @param array - Array to sort
	 */
	@TimeComplexity("O(n^2")
	public void sort(K[] array) {
		for(int i = 1; i < array.length; i++) {
			K temp = array[i];			// temp variable of element at a[i]
			int j = i - 1;				
			while(j >= 0 && array[j].compareTo(temp) > 0) {	
				array[j + 1] = array[j];	// puts element at j in j + 1
				j--;
			}
			array[j + 1] = temp;		// puts temp element at j + 1
		}
	} 
}
