package cs2321.sorting;
/**
 * Kyla Kane-Maystead
 * Assignment 4
 * This class is designed to sort an array using InPlaceSelection Sort
 */
public class InPlaceSelectionSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place selection sort
	 * @param array - Array to sort
	 */
	@TimeComplexity("O(n^2")
	public void sort(K[] array) {
		for(int i = 0; i < array.length - 1; i++) {
			int minIndex = i;
			for(int j = i + 1; j < array.length; j++) {
				if(array[minIndex].compareTo(array[j]) > 0) 	// If element at minIndex is greater than at j, then j is minIndex
					minIndex = j;
			}
			if(minIndex != i)
				swap(array, i, minIndex);			// Swap element at i with minIndex to get the min
		}
	}
	
	@TimeComplexity("O(1)")
	public void swap(K[] array, int i, int j) {
		K temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
}
