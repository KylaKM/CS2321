/**
 * Kyla Kane-Maystead
 * Assignment 4
 * This class is designed to sort an array using Merge sort. 
 */
package cs2321.sorting;
import java.util.Arrays;

public class MergeSort<E extends Comparable<E>> implements Sorter<E> {

	@TimeComplexity("O(nlogn)")
	public void sort(E[] array) {
		if (array.length == 1)  // If length is 1, return
			return;
		int mid = array.length / 2;		// Middle of array
		E[] a1 = Arrays.copyOfRange(array, 0, mid);		// Copy first half of array
		E[] a2 = Arrays.copyOfRange(array, mid, array.length);		// Copy second half of array
		sort(a1);
		sort(a2);
		merge(a1, a2, array);
	}
	
	@TimeComplexity("O(n)")
	public void merge(E[] a1, E[] a2, E[] a) {
		int i = 0;
		int j = 0;
		int k = 0;
		while (i < a1.length && j < a2.length) {
			if(a1[i].compareTo(a2[j]) < 0) {	// If element in a1 is less than element in a2
				a[k] = a1[i];					// Put element in a1 into a at k
				i++;
				k++;
			}
			else {
				a[k] = a2[j];	// Put element in a2 into a at k
				j++;
				k++;
			}
		}
		while (i < a1.length) {		// If j is at the end of a2, then put the rest of it into a
			a[k] = a1[i];
			i++;
			k++;
		}
		while (j < a2.length) {		// If i is at the end of a1, then put the rest of it into a
			a[k] = a2[j];
			j++;
			k++;
		}
	}
}

