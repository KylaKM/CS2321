/**
 * Kyla Kane-Maystead
 * Assignment 4
 * This class is designed sort an array utilizing a Priority Queue
 */
package cs2321.sorting;

import net.datastructures.*;
/**
 * A class that performs three forms of PQ Sort:
 *   SelectionSort (Unordered PQ)
 *   InsertionSort (Ordered PQ)
 *   HeapSort (Heap PQ)
 *
 * @author CS2321 Instructor
 * @param <K>
 */
public abstract class PQSort<K extends Comparable<K>>{
	/*
	 * Simple MinPQSort - relies on a functional minimum PQ and 
	 * a Sequence's addLast, first, last, and next operations are used.
	 */
	@TimeComplexity("O(n^2)")
	protected void sort(K[] kArray, PriorityQueue<K,K> pq) {
		/* TCJ
		 * The worst case time complexity depends on the type
		 * of pq that is implemented. If it is an ordered or 
		 * unordered pq, then it is O(n^2). But, if it is a 
		 * heapPQ, then the worst case is O(nlogn).
		 */
		for(int i = 0; i < kArray.length; i++) 
			pq.insert(kArray[i], null);			// insert elements of array into pq	
		for (int j = 0; j < kArray.length; j++) 
			kArray[j] = pq.removeMin().getKey();	// remove element with min key and put into array in sorted order
 	}	
	

}
