/**
 * Kyla Kane-Maystead
 * Assignment 4
 * This class is designed to sort an array using Quick sort. 
 */
package cs2321.sorting;

public class QuickSort<E extends Comparable<E>> implements Sorter<E> {

	@TimeComplexity("O(n^2)")
	public void sort(E[] array) {
		quickSort(array, 0, array.length - 1);
	}
	
	@TimeComplexity("O(n)")
	public void quickSort(E[] a, int l, int r) {
		if (l < r) {
			int p = partition(a, l, r);		// Get index of partition/pivot
			quickSort(a, l, p - 1);			// Sort left side of pivot
			quickSort(a, p + 1, r);			// Sort right side of pivot
		}
	}
	
	@TimeComplexity("O(n)")
	public int partition(E[] a, int l, int r) {
		int i = l;
		int j = r - 1;
		while (i <= j) {
			while (i <= j && a[i].compareTo(a[r]) <= 0) {	// If element at i is less than pivot, proceed
				i++;
			}
			while (i <= j && a[j].compareTo(a[r]) >= 0) {	// If element at j is greater than pivot, proceed
				j--;
			}
			if(i < j) {		// If element at i is greater than pivot
				swap(a, i, j);	// Swap elements at i and j
				i++;
				j--;
			}
		}
		swap(a, i, r);		// Swap pivot with element at i
		return i;
	}
	
	@TimeComplexity("O(1)")
	public void swap(E[] array, int i, int j) {
		E temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
}
