package cs2321.sorting;

public interface Sorter<E> {
	public void sort(E[] array);
}
