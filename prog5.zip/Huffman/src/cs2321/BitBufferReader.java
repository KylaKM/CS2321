package cs2321;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/************ 
 * support to read from a file at level of bit of 0,1 and return an int value of 0 and 1. 
 * support to read from a file at level of sequence of bits, and return an  string
 * support to read 32 bits, and return an int value
 * 
 * ************/


public class BitBufferReader {
	DataInputStream infile = null;

	int read_buffer=0;
	int read_length=0;  // the buffer length
	String file;

	public BitBufferReader(String filename) {
		file = filename;
	}
	
	public void open() {
		try {
			infile = new DataInputStream(new FileInputStream(file));
			read_length=0;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void close(   ) {
		try {
			infile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 *Return 0 if the next bit is 0
	 *	     1 if the next bit is 1
	 *       -1 if no more data 		  
	 */
	public int readBit() {
		int mask = (1<<7);
		if (read_length==0) {
			try {
				read_buffer = infile.read();
				if (read_buffer == -1) {
					throw new EOFException();
				}
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(-1);
			}
			read_length = 8;
		}	
		int bit = read_buffer & mask;
		read_buffer = read_buffer <<1;
		read_length--;
		if (bit == mask) {
			return 1;
		} else {
			return 0;
		}	
	}
	
	/*
	 *Return the next 8 bits 		  
	 */
	public int readChar()  {
		int data=0;
		
		for (int i=0;i<=7;i++) {
			int b = readBit(   );
			data = data + b;
			if (i<7) {
				data = data <<1;
			}
		}
		return data;
	}
	
	/*
	 *Return the next 32 bits  
	 */
	public int readInt() {
		int data=0;
		for (int i=1;i<=4;i++) {
			int nextByte=readChar();
			data=data<<8;
			data = data + nextByte;
		}
		return data;
	}

}
