package cs2321;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

/************ 
 * support to write to a file at level of bit of 0,1 using int value of 0 and 1. 
 * support to write to a file at lavel of sequence of bits using string
 * support to write a int value with 32 bits. 
 * support padding the output to be multiple of 8 bits.  
 * ************/

public class BitBufferWriter {

	int write_buffer=0;
	int write_length=0;  // the buffer length
	DataOutputStream outfile=null;
	String file;
	
	public BitBufferWriter(String filename) {
		file = filename;
	}
	public void open() {
		try {

			outfile = new DataOutputStream(new FileOutputStream(file));
			write_length = 0;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void close()  {
		try {
			if (write_length > 0) {
				write_buffer = write_buffer << 8 - write_length;
				outfile.write(write_buffer);
			} 
			outfile.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}
		
	}

	public void writeBit(int c) {
		if (c!=0 && c!=1) {
			throw new IllegalArgumentException(""+c);
		}
		write_buffer = write_buffer << 1;
		write_buffer = write_buffer + c;
		write_length++;
		
		if (write_length == 8) {
			try {
				outfile.write(write_buffer);		
				write_length = 0;
				write_buffer = 0;
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(-1);
			}
		}	
	}
	
	
	public void writeByte(int data) {
		int mask = (1<<7);

		for (int i=0;i<8;i++) {
			int b =( data & mask);
			if (b==mask) {
				writeBit(1) ;
			}	else {
				writeBit(0);
			}
			data = data<<1;
		}
	}

	
	public void writeInt(int size) {
		int mask = 1<<31;
		int bit;
		
		for (int i=0;i<32;i++) {
			bit = size & mask;
			size = size <<1;
			if (bit == mask) {
				writeBit(1);
			}else {
				writeBit( 0);
			}
		}

	}

	public void writeString(String code) {
		for (int i=0; i<code.length(); i++) {
			writeBit( Character.getNumericValue(code.charAt(i)));
		}	
	}

}
