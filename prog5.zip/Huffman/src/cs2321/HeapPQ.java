package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A Adaptable PriorityQueue based on an heap. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Kyla Kane-Maystead
 */

public class HeapPQ<K,V> implements AdaptablePriorityQueue<K,V> {

	// Instance Variables
	protected ArrayList<Entry<K,V>> heap = new ArrayList<>();
	private Comparator<K> c;
	
	protected static class PQEntry<K,V> implements Entry<K,V> {
		private K k;
		private V v;
		
		public PQEntry(K key, V value) {
			k = key;
			v = value;
		}
		
		public K getKey() {
			return k;
		}
		
		public V getValue() {
			return v;
		}
		
		protected void setKey(K key) {
			k = key;
		}
		
		protected void setValue(V value) {
			v = value;
		}
	}
	
	protected static class AdaptablePQEntry<K,V> extends PQEntry<K,V> {
		private int index;
		
		public AdaptablePQEntry(K key, V value, int j) {
			super(key, value);
			index = j;
		}
		
		public int getIndex() {
			return index;
		}
		
		public void setIndex(int j) {
			index = j;
		}
	}
	
	// Constructors
	public HeapPQ() {
		this(new DefaultComparator<K>());
	}
	
	public HeapPQ(Comparator<K> c) {
		this.c = c;
	}
	
	/**
	 * This method returns the index of the parent
	 * at a certain index, j
	 * @param j index of child node
	 * @return index of parent node
	 */
	protected int parent(int j) {
		return (j - 1) / 2;
	}
	
	/**
	 * This method returns the index of the
	 * left child at a certain index, j
	 * @param j index of parent node
	 * @return index of left child node
	 */
	protected int left(int j) {
		return (2 * j) + 1;
	}
	
	/**
	 * This method returns the index of the right child
	 * @param j index of parent node
	 * @return index of right child node
	 */
	protected int right(int j) {
		return (2 * j) + 2;
	}
	
	/**
	 * This method returns true if the parent node has
	 * a left child, false otherwise
	 * @param j index of parent node
	 * @return true if parent node has a left child, false otherwise
	 */
	protected boolean hasLeft(int j) {
		return left(j) < heap.size();
	}
	
	/**
	 * This method returns true if the parent node has
	 * a right child, false otherwise
	 * @param j index of parent node
	 * @return true if parent node has a right child, false otherwise
	 */
	protected boolean hasRight(int j) {
		return right(j) < heap.size();
	}
	
	/**
	 * Validates entry to see if it is an instance of AdaptablePQEntry and if it is 
	 * within size of array
	 * @param entry
	 * @return entry if it is valid
	 * @throws IllegalArgumentException if entry is invalid
	 */
	@TimeComplexity("O(1)")
	protected AdaptablePQEntry<K,V> validate(Entry<K,V> entry) throws IllegalArgumentException {
		if(!(entry instanceof AdaptablePQEntry)) 		// If parameter is not an instance of AdaptablePQEntry
			throw new IllegalArgumentException("Invalid Entry");		
		AdaptablePQEntry<K,V> locate = (AdaptablePQEntry<K,V>) entry;
		int j = locate.getIndex();
		if(j >= heap.size() || heap.get(j) != locate)		// If index is not in range of list and entry at the index doesn't equal locate 
			throw new IllegalArgumentException("Invalid Entry");
		return locate;
	}
	
	/**
	 * Swap the entries with two indices 
	 * @param i index
	 * @param j index
	 */
	@TimeComplexity("O(n)")
	protected void swap(int i, int j) {
		Entry<K,V> temp = heap.get(i);		// Get entry at index i
		heap.set(i, heap.get(j));		// Set entry index i to be entry at index j
		heap.set(j, temp);				// Set entry at index j to be entry at index i
	}
	
	/**
	 * The entry should be bubbled up to its appropriate position 
	 * @param int move the entry at index j higher if necessary, to restore the heap property
	 */
	@TimeComplexity("O(n)")
	public void upheap(int j){
		if(j == 0)
			return;
		int p = parent(j);
		if(c.compare(heap.get(j).getKey(), heap.get(p).getKey()) < 0 ) {    // If child's key is less than parent's key
			swap(j, p);		// Swap child with parent
			upheap(p);		// upheap parent
		}
	}
	
	/**
	 * The entry should be bubbled down to its appropriate position 
	 * @param int move the entry at index j lower if necessary, to restore the heap property
	 */
	@TimeComplexity("O(n)")
	public void downheap(int j){
		if(!hasLeft(j)) 	
			return;
		int s = left(j);		// Left Child
		int r = right(j);		// Right Child
		if(hasRight(j) && c.compare(heap.get(r).getKey(), heap.get(s).getKey()) < 0 ) // If parent has a right child, and right child is less than left
			s = r;
		if(c.compare(heap.get(s).getKey(), heap.get(j).getKey()) < 0) { 	// If left child is less than parent
			swap(s, j);			// Swap parent with left child
			downheap(s);		// downheap left child
		}
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return heap.size();
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return heap.size() == 0;
	}

	/**
	 * Determine whether the entry needs to upheap or downheap
	 * @param j index
	 */
	@TimeComplexity("O(n)")
	protected void bubble(int j) {
		if(j > 0 && c.compare(heap.get(j).getKey(), heap.get(parent(j)).getKey()) < 0) 		// If index is greater than zero and child is less than parent
			upheap(j);
		else
			downheap(j);
	}
	
	/**
	 * Checks whether the key is valid
	 * @param key
	 * @return true if key is valid, otherwise false
	 * @throws IllegalArgumentException if key is invalid
	 */
	@TimeComplexity("O(1)")
	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (c.compare(key, key) == 0);
		}
		catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible key");
		}
	}
	
	@Override
	@TimeComplexity("O(logn)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		/* TCJ
		 * Since the pq is using a heap the height of the heap is logn. So when an element is 
		 * inserted at the end of the heap, it will go through at most logn elements to upheap
		 * to proper place in heap.
		 */
		checkKey(key);
		Entry<K, V> newest = new AdaptablePQEntry<>(key, value, heap.size());
		heap.addLast(newest);		// Add entry to end
		upheap(heap.size() - 1);	// Upheap entry
		return newest;
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> min() {
		if(isEmpty())		// If empty, return null
			return null;
		return heap.get(0);		// Return root node
	}

	@Override
	@TimeComplexity("O(logn)")
	public Entry<K, V> removeMin() {
		/* TCJ
		 * Since the pq is using a heap the height of the heap is logn so when the 
		 * root and the last leaf node are swapped, it will go through logn elements 
		 * to downheap the entry to its proper place.  
		 */
		if(isEmpty())		// If empty, return null
			return null;
		Entry<K, V> answer = heap.get(0);	// Get root node
		swap(0, heap.size() - 1);			// Swap the root with the last node
		heap.remove(heap.size() - 1);		// Remove the last node that was the root node
		downheap(0);						// Downheap the new root node
		return answer;
	}

	@Override
	@TimeComplexity("O(logn)")
	public void remove(Entry<K, V> entry) throws IllegalArgumentException {
		/* TCJ
		 * Since the pq is using a heap the height of the heap is logn so when the 
		 * two nodes are swapped, it will go through logn elements 
		 * to downheap the entry to its proper place at worst case. 
		 */
		AdaptablePQEntry<K, V> locate = validate(entry);
		int j = locate.getIndex();
		if(j == heap.size() - 1)		// If index is equal to size - 1
			heap.remove(heap.size() - 1);	// Remove the last node
		else {
			swap(j, heap.size() - 1);		// Swap locate with last node
			heap.remove(heap.size() - 1);	// Remove the last node
			bubble(j);						// Bubble the new entry at this index
		}
	}

	@Override
	@TimeComplexity("O(logn)")
	public void replaceKey(Entry<K, V> entry, K key) throws IllegalArgumentException {
		/* TCJ
		 * Since this method can replace a key, it will need to upheap
		 * or downheap the updated entry based on whether the key is
		 * greater than or less than it's parent node or child nodes. However,
		 * it will only need to go through about half of the nodes at worst
		 * case. 
		 */
		AdaptablePQEntry<K, V> locate = validate(entry);
		checkKey(key);		// Checks if key is valid
		locate.setKey(key);		// Set key of entry
		bubble(locate.getIndex());	// Upheap or Downheap entry depending on key value
	}

	@Override
	@TimeComplexity("O(1)")
	public void replaceValue(Entry<K, V> entry, V value) throws IllegalArgumentException {
		AdaptablePQEntry<K, V> locate = validate(entry);
		locate.setValue(value);		// Set value of entry
	}
}
