package cs2321;

import net.datastructures.*;
import java.io.FileReader;
import java.io.IOException;
/**
 * Kyla Kane-Maystead
 * Assignment 5
 * This class is designed to compress a file using Huffman's code.
 */

public class HuffmanCompress {
	
	//Instance Variables
	private LinkedBinaryTree<Character> tree = new LinkedBinaryTree<Character>();
	private String[] codeTable = new String[256];
	private FileReader in;
	private BitBufferWriter out;
	private HeapPQ<Integer, LinkedBinaryTree<Character>> pq = new HeapPQ<Integer, LinkedBinaryTree<Character>>();
	
	/**
	 * 
	 * Compress file using Huffman code.  
	 *
	 * The compressed data file shall have three parts: 
	 *       prefix encode tree, original data length, and the data encoded with Huffman code. 
	 *       
	 * prefix encode tree should be represented as following: 
	 * if the node is external, output 0, followed by the letter's ascii code
	 * if the node is internal, output 1, followed by 
	 *  		the bit stream of left subtree, then the bit stream of right subtree. 
 
	 * @param inputFile  The original data file
	 * @param outputFile  The compressed data file. 
	 * @return the number of bits after encoding the data with Huffman code. 
	 * @throws IOException 
	 */
	public int compress(String inputFile, String outputFile) throws IOException {
		try {
			in = new FileReader(inputFile);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		// Generate Frequency Table
		int[] freq = new int[256];
		for(int i = 0; i < 256; i++) {
			freq[i] = 0;
		}
		
		// Count Frequency of characters and put into freq array
		int inputLength = 0;
		int ch;
		while((ch = in.read()) != -1) {
			freq[ch]++;
			inputLength++;
		}
		
		in.close();
		
		// Make each character it's own tree and put into pq
		for(int i = 0; i < 256; i++) {
			if(freq[i] != 0) {
				LinkedBinaryTree<Character> newT = new LinkedBinaryTree<Character>();
				newT.addRoot((char)i);
				pq.insert(freq[i], newT);
			}
		}
		
		// Build the Encode Tree
		while(pq.size() > 1) {
			Entry<Integer, LinkedBinaryTree<Character>> min1 = pq.removeMin();
			Entry<Integer, LinkedBinaryTree<Character>> min2 = pq.removeMin();
			int cfreq = min1.getKey() + min2.getKey();
			LinkedBinaryTree<Character> newT = new LinkedBinaryTree<Character>();
			newT.addRoot(' ');
			newT.attach(newT.root(), min1.getValue(), min2.getValue());
			pq.insert(cfreq, newT);
		}
	
		tree = pq.removeMin().getValue();
		
		// Call buildCodeTable method the build the code table
		buildCodeTable(tree.root(), "");
		
		out = new BitBufferWriter(outputFile);
		out.open();
	
		// Write the prefix Tree
		writePrefixTree(tree.root(), out);
		
		// Write the length of the input data
		out.writeInt(inputLength);
		
		in = new FileReader(inputFile);
		// Write data encoded with Huffman and keep track of length of encoded data
		int c;
		int encodeLength = 0;
		while((c = in.read()) != -1) {
			out.writeString(codeTable[c]);
			encodeLength += codeTable[c].length();
		}
		
		// Close files
		in.close();
		out.close();
	
		return encodeLength;
	}
	
	public void buildCodeTable(Position<Character> v, String code) {
		
		// If external then, return the string of 0's and 1's
		if(tree.isExternal(v))
			codeTable[v.getElement()] = code;
		// Otherwise call buildCodeTable for left and right subtree
		// and putting a 0 for left and 1 for right in code
		else {
			buildCodeTable(tree.left(v), code + "0");
			buildCodeTable(tree.right(v), code + "1");
		}
	}
	
	public void writePrefixTree(Position<Character> v, BitBufferWriter out) {
		
		// If the node is external then write a 0 and the ascii code of character
		if(tree.isExternal(v)) {
			out.writeBit(0);
			out.writeByte(v.getElement());
		}
		
		// Otherwise, write a 1 and call writePrefixTree for left and right subtree
		else {
			out.writeBit(1);
			writePrefixTree(tree.left(v), out);
			writePrefixTree(tree.right(v), out);
		}
		
	}
}
