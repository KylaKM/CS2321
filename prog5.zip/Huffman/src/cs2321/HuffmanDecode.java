package cs2321;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import net.datastructures.*;
/**
 * Kyla Kane-Maystead
 * Assignment 5
 * This class is designed to decode a file that has been encoded with Huffman's algorithm.
 */

/*
 * Encoding prefix tree bit stream: 
 * if the node is external, output 1, followed by the letter
 * if the node is internal, output 0, followed by 
 *  		the bit stream of left subtree, then the bit stream of right subtree. 
 */
public class HuffmanDecode {
	
	private LinkedBinaryTree<Character> tree = new LinkedBinaryTree<Character>();
	private BitBufferReader in;
	private FileWriter out;
	private Position<Character> v;
	
	/**
	 * Decode the compressed data file back to the original data file with ascii code. 
	 * 
	 * The compressed data file has three parts: 
	 *       prefix encode tree, original data length, and the data encoded with Huffman code.
	 *       
	 * @param inputFile the compressed data file
	 * @param outputFile the file with ascii code. 
	 * @throws IOException 
	 */
	public void decode(String inputFile, String outputFile) throws IOException {	
		
		// Open BitBufferReader input file to read
		in = new BitBufferReader(inputFile);
		in.open();
		
		// Open output file to write
		try {
			out = new FileWriter(outputFile);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		// Call readPrefixTree to reconstruct the encode tree
		tree = readPrefixTree();
		
		// Read the file length
		int length = in.readInt();
		
		//Decode until correct number of characters are decoded
		for(int i = 1; i <= length; i++) {
			
			v = tree.root(); 		// v to root
			
			while(tree.isInternal(v)) {				// while v is internal
				int b = in.readBit();				// read next bit
				
				if(b == 0) 
					v = tree.left(v);				// If bit is 0, then go to left
				
				else
					v = tree.right(v);				// Otherwise, go to right
			}
			
			try {
				// write v's element to file
				out.write(v.getElement());
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		// close files
		in.close();
		try {
			out.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public LinkedBinaryTree<Character> readPrefixTree() {
		
		// Read the next bit
		int bit = in.readBit();
		
		// If bit is 0, then read next 8 bits and create a tree with that character, and return tree
		if(bit == 0) {
			int ch = in.readChar();
			LinkedBinaryTree<Character> newT = new LinkedBinaryTree<Character>();
			newT.addRoot((char)ch);
			return newT;
		}
		// Otherwise, call readPrefixTree for left subtree and right subtree, merge them 
		// to be a bigger tree and return that tree
		else {
			LinkedBinaryTree<Character> t1 = readPrefixTree();
			LinkedBinaryTree<Character> t2 = readPrefixTree();
			LinkedBinaryTree<Character> newT = new LinkedBinaryTree<Character>();
			newT.addRoot(' ');
			newT.attach(newT.root(), t1, t2);
			return newT;
		}
	}
}
