package cs2321;
import java.util.Iterator;

import net.datastructures.*;

/**
 * Kyla Kane-Maystead
 * Assignment 5
 * This class is designed to create a Linked Binary Tree data structure. 
 */

public class LinkedBinaryTree<E> implements BinaryTree<E>{
	
	private class ElementIterator implements Iterator<E> {
		Iterator<Position<E>> posIterator = positions().iterator();
		
		public boolean hasNext() {
			return posIterator.hasNext();
		}
		
		public E next() {
			return posIterator.next().getElement();
		}
		
		public void remove() {
			posIterator.remove();
		}
 	}

	protected static class Node<E> implements Position<E> {
		private E element;
		private Node<E> parent, left, right;
		
		public Node(E e, Node<E> above, Node<E> leftChild, Node<E> rightChild) {
			element = e;
			parent = above;
			left = leftChild;
			right = rightChild;
		}
		
		public E getElement() {
			return element;
		}
		
		public Node<E> getParent() {
			return parent;
		}
		
		public Node<E> getLeft() {
			return left;
		}
		
		public Node<E> getRight() {
			return right;
		}
		
		public void setElement(E e) {
			element = e;
		}
		
		public void setParent(Node<E> parentNode) {
			parent = parentNode;
		}
		
		public void setLeft(Node<E> leftChild) {
			left = leftChild;
		}
		
		public void setRight(Node<E> rightChild) {
			right = rightChild;
		}
	}
	
	protected Node<E> createNode(E e, Node<E> parent, Node<E> left, Node<E> right) {
		return new Node<E>(e, parent,left, right);
	}
	
	// Instance variables
	protected Node<E> root = null;
	private int size = 0;
	
	@Override
	@TimeComplexity("O(1)")
	public Position<E> root() {
		return root;
	}
	
	public  LinkedBinaryTree( ) {	
		root = null;
		size = 0;
	}
	
	protected Node<E> validate(Position<E> p) throws IllegalArgumentException {
		if(!(p instanceof Node))
			throw new IllegalArgumentException("Not valid position type");
		Node<E> node = (Node<E>) p;
		if(node.getParent() == node)
			throw new IllegalArgumentException("p is no longer in the tree");
		return node;
	}
	
	/** Replaces the element at Position p with e and returns the replaced element */
	@TimeComplexity("O(1)")
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = validate(p);
		E temp = node.getElement();
		node.setElement(e);
		return temp;
	}
	
	@Override
	@TimeComplexity("O(1)")
	public Position<E> parent(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node.getParent();
	}

	@Override
	@TimeComplexity("O(1)")
	public Iterable<Position<E>> children(Position<E> p) throws IllegalArgumentException {
		ArrayList<Position<E>> list = new ArrayList<>(2);
		if(left(p) != null)
			list.addLast(left(p));
		if(right(p) != null)
			list.addLast(right(p));
		return list;
	}

	@Override
	@TimeComplexity("O(1)")
	/* count only direct child of the node, not further descendant. */
	public int numChildren(Position<E> p) throws IllegalArgumentException {
		int count = 0;
		if(left(p) != null) {
			count++;
		}
		if(right(p) != null) {
			count++;
		}
		return count;
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isInternal(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return numChildren(node) > 0;
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isExternal(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return numChildren(node) == 0;
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isRoot(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node == root();
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	public Iterator<E> iterator() {
		return new ElementIterator();
	}

	@Override
	public Iterable<Position<E>> positions() {
		return preorder();
	}
	
	private void preorderSubtree(Position<E> p, ArrayList<Position<E>> list) {
		list.addLast(p);
		for(Position<E> c : children(p)) {
			preorderSubtree(c, list);
		}
	}
	
	public Iterable<Position<E>> preorder() {
		ArrayList<Position<E>> list = new ArrayList<>();
		if(!isEmpty()) 
			preorderSubtree(root(), list);
		return list;
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> left(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node.getLeft();
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> right(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node.getRight();
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> sibling(Position<E> p) throws IllegalArgumentException {
		Position<E> parent = parent(p);
		if(parent == null) {
			throw new IllegalArgumentException("");		// Must be root
		}
		if(p == left(parent)) {
			return right(parent);		// return right sibling
		}
		else {
			return left(parent);		// return left sibling
		}
	}
	
	/* creates a root for an empty tree, storing e as element, and returns the 
	 * position of that root. An error occurs if tree is not empty. 
	 */
	@TimeComplexity("O(1)")
	public Position<E> addRoot(E e) throws IllegalStateException {
		if(!isEmpty())
			throw new IllegalStateException("Tree is not empty");
		root = createNode(e, null, null, null);
		size = 1;
		return root;
	}
	
	/* creates a new left child of Position p storing element e, return the left child's position.
	 * If p has a left child already, throw exception IllegalArgumentExeption. 
	 */
	@TimeComplexity("O(1)")
	public Position<E> addLeft(Position<E> p, E e) throws IllegalArgumentException {
		 Node<E> parent = validate(p);
		 if(parent.getLeft() != null) 
			 throw new IllegalArgumentException("p already has left child");
		 Node<E> child = createNode(e, parent, null, null);
		 parent.setLeft(child);
		 size++;
		 return child;
	}

	/* creates a new right child of Position p storing element e, return the right child's position.
	 * If p has a right child already, throw exception IllegalArgumentExeption. 
	 */
	@TimeComplexity("O(1)")
	public Position<E> addRight(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> parent = validate(p);
		 if(parent.getRight() != null) 
			 throw new IllegalArgumentException("p already has right child");
		 Node<E> child = createNode(e, parent, null, null);
		 parent.setRight(child);
		 size++;
		 return child;
	}
	
	/* Attach trees t1 and t2 as left and right subtrees of external Position. 
	 * if p is not external, throw IllegalArgumentExeption.
	 */
	@TimeComplexity("O(1)")
	public void attach(Position<E> p, LinkedBinaryTree<E> t1, LinkedBinaryTree<E> t2)
			throws IllegalArgumentException {
		Node <E> node = validate(p);
		if(isInternal(p))
			throw new IllegalArgumentException("p must be a leaf");
		size += t1.size() + t2.size();
		if(!t1.isEmpty()) {				// attach t1 as left subtree of node
			t1.root.setParent(node);
			node.setLeft(t1.root);
			t1.root = null;
			t1.size = 0;
		}
		if(!t2.isEmpty()) {				// attach t2 as right subtree of node
			t2.root.setParent(node);
			node.setRight(t2.root);
			t2.root = null;
			t2.size = 0;
		}
	}
	
	@TimeComplexity("O(1)")
	public E remove(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		if(numChildren(p) == 2)
			throw new IllegalArgumentException("p has two children");
		Node<E> child = (node.getLeft() != null ? node.getLeft() : node.getRight());
		if(child != null)
			child.setParent(node.getParent());		// Child's grandparent becomes its parent
		if(node == root)
			root = child;			// Child becomes root
		else {
			Node<E> parent = node.getParent();
			if(node == parent.getLeft())
				parent.setLeft(child);
			else
				parent.setRight(child);
		}
		size--;
		E temp = node.getElement();
		node.setElement(null);				// help garbage collection
		node.setLeft(null);
		node.setRight(null);
		node.setParent(node);
		return temp;
	}
}
