package cs2321;

import java.util.Comparator;

import net.datastructures.Entry;
import net.datastructures.Position;
import net.datastructures.SortedMap;

/**
 * Kyla Kane-Maystead
 * Assignment 6
 * This class is designed to create a Binary Search Tree using a LinkedBinaryTree Structure.
 */

public class BinarySearchTree<K extends Comparable<K>,V> extends AbstractMap<K,V> implements SortedMap<K,V> {
	
	/* all the data will be stored in tree*/
	LinkedBinaryTree<Entry<K,V>> tree; 
	int size;  //the number of entries (mappings)
	Comparator<K> c;
	
	/* 
	 * default constructor
	 */
	public BinarySearchTree() {
		tree = new LinkedBinaryTree<Entry<K, V>>(); 
		tree.addRoot(null);
	}
	
	public BinarySearchTree(Comparator<K> c) {
		tree = new LinkedBinaryTree<Entry<K, V>>(); 
		tree.addRoot(null);
		this.c = c;
	}
	
	/* 
	 * Return the tree. The purpose of this method is purely for testing. 
	 * You don't need to make any change. Just make sure to use object tree to store your entries. 
	 */
	public LinkedBinaryTree<Entry<K,V>> getTree() {
		return tree;
	}
	
	private Position<Entry<K, V>> treeSearch(Position<Entry<K, V>> p, K key) {
		if(tree.isExternal(p))
			return p;
		else if(p.getElement().getKey().equals(key))
			return p;
		else if(p.getElement().getKey().compareTo(key) < 0)
			return treeSearch(tree.right(p), key);
		else
			return treeSearch(tree.left(p), key);
	}
	
	protected Position<Entry<K, V>> root() {
		return tree.root();
	}
	
	@Override
	public int size(){
		return (tree.size() - 1) / 2;
	}
	
	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (key.compareTo(key) == 0);
		}
		catch(ClassCastException e) {
			throw new IllegalArgumentException("Incompatible Key");
		}
	}
	
	@Override
	@TimeComplexity("O(h)")
	public V get(K key) throws IllegalArgumentException {
		checkKey(key);
		Position<Entry<K, V>> p = treeSearch(tree.root(), key);
		if(tree.isExternal(p))
			return null;
		else
			return p.getElement().getValue();
	}
	
	private void expandExternal(Position<Entry<K, V>> p, Entry<K, V> entry) {
		tree.set(p, entry);
		tree.addLeft(p, null);
		tree.addRight(p, null);
	}

	@Override
	@TimeComplexity("O(h)")
	public V put(K key, V value) throws IllegalArgumentException {
		checkKey(key);
		Entry<K, V> newEntry = new mapEntry<>(key, value);
		Position<Entry<K, V>> p = treeSearch(tree.root(), key);
		if(tree.isExternal(p)) {
			expandExternal(p, newEntry);
			return null;
		}
		else {
			V old = p.getElement().getValue();
			tree.set(p, newEntry);
			return old;
		}
	}

	private void removeExternalAndParent(Position<Entry<K, V>> v) {
		Position<Entry<K, V>> p = tree.parent(v);
		tree.remove(v);
		tree.remove(p);
	}
	
	@Override
	@TimeComplexity("O(h)")
	public V remove(K key) throws IllegalArgumentException {
		checkKey(key);
		Position<Entry<K, V>> p = treeSearch(tree.root(), key);
		if(tree.isExternal(p))
			return null;
		V old = p.getElement().getValue();
		if(tree.isExternal(tree.left(p)))
			removeExternalAndParent(tree.left(p));
		else if(tree.isExternal(tree.right(p)))
			removeExternalAndParent(tree.right(p));
		else {
			Position<Entry<K, V>> w = tree.right(p);
			while(tree.left(w) != null)
				w = tree.left(w);
			tree.set(p, tree.parent(w).getElement());
			removeExternalAndParent(w);
		}
		return old;
	}


	@Override
	public Iterable<Entry<K, V>> entrySet() {
		ArrayList<Entry<K, V>> buffer = new ArrayList<>(size());
		for(Position<Entry<K,V>> p : tree.preorder())
			if(tree.isInternal(p))
				buffer.addLast(p.getElement());
		return buffer;
	}
	
	@Override
	public Entry<K, V> firstEntry() {
		return root().getElement();
	}

	protected Position<Entry<K, V>> treeMax(Position<Entry<K, V>> p) {
		Position<Entry<K, V>> walk = p;
		while(tree.isInternal(walk))
			walk = tree.right(walk);
		return tree.parent(walk);
	}
	
	@Override
	public Entry<K, V> lastEntry() {
		if(isEmpty())
			return null;
		return treeMax(root()).getElement();
	}

	@Override
	public Entry<K, V> ceilingEntry(K key) {
		Position<Entry<K, V>> v = treeSearch(root(), key);
		return (Entry<K, V>) treeMax(v);
	}

	@Override
	public Entry<K, V> floorEntry(K key) throws IllegalArgumentException {
		checkKey(key);
		Position<Entry<K, V>> p = treeSearch(root(), key);
		if(tree.isInternal(p))
			return p.getElement();
		while(!tree.isRoot(p)) {
			if(p == tree.right(p))
				return tree.parent(p).getElement();
			else
				p = tree.parent(p);
		}
		return null;
	}

	@Override
	public Entry<K, V> lowerEntry(K key) throws IllegalArgumentException {
		checkKey(key);
		Position<Entry<K, V>> p = treeSearch(root(), key);
		if(tree.isInternal(p) && tree.isInternal(tree.left(p)))
			return treeMax(tree.left(p)).getElement();
		while(!tree.isRoot(p)) {
			if(p == tree.right(tree.parent(p)))
				return tree.parent(p).getElement();
			else
				p = tree.parent(p);
		}
		return null;
	}

	@Override
	public Entry<K, V> higherEntry(K key){
		Position<Entry<K, V>> p = treeSearch(root(), key);
		return p.getElement();
	}

	@Override
	public Iterable<Entry<K, V>> subMap(K fromKey, K toKey)
			throws IllegalArgumentException {
		checkKey(fromKey);
		checkKey(toKey);
		ArrayList<Entry<K, V>> buffer = new ArrayList<>(size());
		if(c.compare(fromKey, toKey) < 0)
			subMapRecurse(fromKey, toKey, root(), buffer);
		return buffer;
	}
	
	private void subMapRecurse(K fromKey, K toKey, Position<Entry<K, V>> p, ArrayList<Entry<K, V>> buffer) {
		if(tree.isInternal(p)) {
			if(c.compare(p.getElement().getKey(), fromKey) < 0)
				subMapRecurse(fromKey, toKey, tree.right(p), buffer);
			else {
				subMapRecurse(fromKey, toKey, tree.right(p), buffer);
				if(c.compare(p.getElement().getKey(), toKey) < 0) {
					buffer.addLast(p.getElement());
					subMapRecurse(fromKey, toKey, tree.right(p), buffer);
				}
			}
		}
	}

	@Override
	public boolean isEmpty() {
		return root() == null;
	}
}
