package cs2321;

import net.datastructures.*;

/**
 * Kyla Kane-Maystead
 * Assignment 6
 * This class is designed to simulate an ordered map using an ArrayList. 
 */

public class LookupTable<K extends Comparable<K>, V> extends AbstractMap<K,V> implements SortedMap<K, V> {
	
	/* Use Sorted ArrayList for the Underlying storage for the map of entries.
	 * 
	 */
	private ArrayList<mapEntry<K,V>> table; 

	
	public LookupTable(){
		table =  new ArrayList<>();
	}
	
	@Override
	public int size() {
		return table.size();
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	public int binarySearch(K key) {
		int left = 0;
		int r = table.size() - 1;
		while(left <= r) {
			int mid = (left + r) / 2;
			if(table.get(mid).getKey().equals(key)) {
				return mid;
			}
			else if(table.get(mid).getKey().compareTo(key) < 0) {
				left = mid + 1;
			}
			else
				r = mid - 1;
		}
		return left;
	}
	
	@Override
	@TimeComplexity("O(logn)")
	public V get(K key) {
		int i = binarySearch(key);
		if(i == table.size())
			return null;
		else if(table.get(i).getKey().equals(key))
			return table.get(i).getValue();
		else
			return null;
	}

	@Override
	@TimeComplexity("O()")
	public V put(K key, V value) {
		int i = binarySearch(key);
		if(i < size() && table.get(i).getKey().equals(key)) {
			V old = table.get(i).getValue();
			table.get(i).setValue(value);
			return old;
		}
		else {
			table.add(i, new mapEntry<K, V>(key, value));
			return null;
		}
	}

	@Override
	@TimeComplexity("O(n)")
	public V remove(K key) {
		int i = binarySearch(key);
		if(i < size() && table.get(i).getKey().equals(key))
			return table.remove(i).getValue();
		else 
			return null;
	}


	@Override
	public Iterable<Entry<K, V>> entrySet() {
		return snapshot(0, null);
	}
	
	private Entry<K, V> safeEntry(int i) {
		if(i < 0 || i >= table.size())
			return null;
		return table.get(i);
	}

	@Override
	public Entry<K, V> firstEntry() {
		return safeEntry(0);
	}

	@Override
	public Entry<K, V> lastEntry() {
		return safeEntry(table.size() - 1);
	}

	@Override
	@TimeComplexity("O(logn)")
	public Entry<K, V> ceilingEntry(K key)  {
		return safeEntry(binarySearch(key));
	}

	@Override
	@TimeComplexity("O(logn)")
	public Entry<K, V> floorEntry(K key)  {
		int i = binarySearch(key);
		if(i == size() || !(key.equals(table.get(i).getKey())))
			i--;
		return safeEntry(i);
	}

	@Override
	public Entry<K, V> lowerEntry(K key) {
		return safeEntry(binarySearch(key) - 1);
	}

	@Override
	public Entry<K, V> higherEntry(K key) {
		int i = binarySearch(key);
		if(i < size() && key.equals(table.get(i).getKey()))
			i++;
		return safeEntry(i);
	}
	
	private Iterable<Entry<K, V>> snapshot(int start, K stop) {
		ArrayList<Entry<K, V>> buffer = new ArrayList<>();
		int i = start;
		while(i < table.size() && (stop == null || stop.compareTo(table.get(i).getKey()) > 0))
			buffer.addLast(table.get(i++));
		return buffer;
	}

	@Override
	public Iterable<Entry<K, V>> subMap(K fromKey, K toKey){
		return snapshot(binarySearch(fromKey), toKey);
	}


}
