package cs2321;

import net.datastructures.*;

/**
 * Kyla Kane-Maystead
 * Assignment 7
 * This class is designed to simulate a graph structure. 
 */

/*
 * Implement Graph interface. A graph can be declared as either directed or undirected.
 * In the case of an undirected graph, methods outgoingEdges and incomingEdges return the same collection,
 * and outDegree and inDegree return the same value.
 * 
 * @author CS2321 Instructor
 */
@SpaceComplexity("n + m")
public class AdjListGraph<V, E> implements Graph<V, E> {

	private class InnerVertex<V> implements Vertex<V> {
		private V element;
		private Position<Vertex<V>> pos;
		private Map<Vertex<V>, Edge<E>> outgoing, incoming;
		
		public InnerVertex(V elem, boolean graphIsDirected) {
			element = elem;
		     outgoing = new HashMap<>();
		     if (graphIsDirected)
		       incoming = new HashMap<>();
		     else
		       incoming = outgoing;    // if undirected, alias outgoing map
		}
		
		public V getElement() {
			return element;
		}
		
		public V setElement(V o) {
			V old = element;
			element = o;
			return old;
		}
		
		public void setPosition(Position<Vertex<V>> p) {
			pos = p;
		}
		
		public Position<Vertex<V>> getPosition() {
			return pos;
		}
		
		public Map<Vertex<V>, Edge<E>> getOutgoing() {
			return outgoing;
		}
		
		public Map<Vertex<V>, Edge<E>> getIncoming() {
			return incoming;
		}
	}
	
	private class InnerEdge<E> implements Edge<E> {
		private E element;
		private Position<Edge<E>> pos;
		private Vertex<V>[] endpoints;
		
		public InnerEdge(Vertex<V> u, Vertex<V> v, E elem) {
			element = elem;
			endpoints = (Vertex<V>[]) new Vertex[] {u, v};
		}
		
		public E getElement() {
			return element;
		}
		
		public E setElement(E o) {
			E old = element;
			element = o;
			return old;
		}
		
		public Vertex<V>[] getEndpoints() {
			return endpoints;
		}
		
		public void setPosition(Position<Edge<E>> p) {
			pos = p;
		}
		
		public Position<Edge<E>> getPosition() {
			return pos;
		}
	}
	
	private boolean isDirected;
	private DoublyLinkedList<Vertex<V>> vertices = new DoublyLinkedList<>();
	private DoublyLinkedList<Edge<E>> edges = new DoublyLinkedList<>();
	
	public AdjListGraph(boolean directed) {
		isDirected = directed; 
	}

	public AdjListGraph() {
		isDirected = false;
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#edges()
	 */
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> edges() {
		return edges;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#endVertices(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V>[] endVertices(Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
	    return edge.getEndpoints();
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertEdge(net.datastructures.Vertex, net.datastructures.Vertex, java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Edge<E> insertEdge(Vertex<V> u, Vertex<V> v, E o)
			throws IllegalArgumentException {
		if (getEdge(u,v) == null) {
		      InnerEdge<E> e = new InnerEdge<>(u, v, o);
		      e.setPosition(edges.addLast(e));
		      InnerVertex<V> origin = validate(u);
		      InnerVertex<V> dest = validate(v);
		      origin.getOutgoing().put(v, e);
		      dest.getIncoming().put(u, e);
		      return e;
		    } 
		else
			throw new IllegalArgumentException("Edge from u to v exists");
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertVertex(java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> insertVertex(V o) {
		InnerVertex<V> v = new InnerVertex<>(o, isDirected);
	    v.setPosition(vertices.addLast(v));
	    return v;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numEdges()
	 */
	@TimeComplexity("O(1)")
	public int numEdges() {
		return edges.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numVertices()
	 */
	@TimeComplexity("O(1)")
	public int numVertices() {
		return vertices.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#opposite(net.datastructures.Vertex, net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> opposite(Vertex<V> v, Edge<E> e)
			throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
	    Vertex<V>[] endpoints = edge.getEndpoints();
	    if (endpoints[0] == v)
	      return endpoints[1];
	    else if (endpoints[1] == v)
	      return endpoints[0];
	    else
	      throw new IllegalArgumentException("v is not incident to this edge");
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeEdge(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public void removeEdge(Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
	    // remove this edge from vertices' adjacencies
	    Vertex<V>[] verts = edge.getEndpoints();
	    InnerVertex<V> v0 = validate(verts[0]);
	    InnerVertex<V> v1 = validate(verts[1]);
	    v0.getOutgoing().remove(v1);
	    v1.getIncoming().remove(v0);
	    // remove this edge from the list of edges
	    edges.remove(edge.getPosition());
	    edge.setPosition(null);             // invalidates the edge
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeVertex(net.datastructures.Vertex)
	 */
	@TimeComplexity("O(deg(v))")
	public void removeVertex(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
	    // remove all incident edges from the graph
	    for (Edge<E> e : vert.getOutgoing().values())
	      removeEdge(e);
	    for (Edge<E> e : vert.getIncoming().values())
	      removeEdge(e);
	    // remove this vertex from the list of vertices
	    vertices.remove(vert.getPosition());
	    vert.setPosition(null);             // invalidates the vertex
	}

	private InnerVertex<V> validate(Vertex<V> v) {
		if (!(v instanceof InnerVertex)) throw new IllegalArgumentException("Invalid vertex");
	    InnerVertex<V> vert = (InnerVertex<V>) v;     // safe cast
	   // if (!vert.validate(this)) throw new IllegalArgumentException("Invalid vertex");
	    return vert;
	}
	
	private InnerEdge<E> validate(Edge<E> e) {
		if (!(e instanceof InnerEdge)) throw new IllegalArgumentException("Invalid edge");
	    InnerEdge<E> edge = (InnerEdge<E>) e;     // safe cast
	  //  if (!edge.validate(this)) throw new IllegalArgumentException("Invalid edge");
	    return edge;
	}
	
	/* 
     * replace the element in edge object, return the old element
     */
	@TimeComplexity("O(1)")
	public E replace(Edge<E> e, E o) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
		return edge.setElement(o);
	}

    /* 
     * replace the element in vertex object, return the old element
     */
	@TimeComplexity("O(1)")
	public V replace(Vertex<V> v, V o) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		return vert.setElement(o);
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#vertices()
	 */
	@TimeComplexity("O(1)")
	public Iterable<Vertex<V>> vertices() {
		return vertices;
	}

	@Override
	@TimeComplexity("O(deg(v)")
	public int outDegree(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
	    return vert.getOutgoing().size();
	}

	@Override
	@TimeComplexity("O(deg(v)")
	public int inDegree(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
	    return vert.getIncoming().size();
	}

	@Override
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> outgoingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
	    return vert.getOutgoing().values();   // edges are the values in the adjacency map
	}

	@Override
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> incomingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
	    return vert.getIncoming().values();   // edges are the values in the adjacency map
	}

	@Override
	@TimeComplexity("O(1)")
	public Edge<E> getEdge(Vertex<V> u, Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> origin = validate(u);
	    return origin.getOutgoing().get(v);    // will be null if no edge from u to v
	}
	
}
